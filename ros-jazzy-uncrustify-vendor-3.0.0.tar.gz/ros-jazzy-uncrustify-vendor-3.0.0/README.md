# uncrustify_vendor
CMake shim over the uncrustify library: https://github.com/uncrustify/uncrustify
